package com.example.lab05.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;

@Controller
@RequestMapping("/user")
@SessionAttributes({"partidas", "numeroAdivinar", "intentos", "numerosIntentados"})
public class JuegoController {

    @ModelAttribute("partidas")
    public List<Map<String, Object>> partidas() {
        return new ArrayList<>();
    }

    @GetMapping("/juego")
    public String juego(Model model) {
        model.addAttribute("numeroAdivinar", new Random().nextInt(100) + 1);
        model.addAttribute("intentos", 0);
        model.addAttribute("numerosIntentados", new ArrayList<Integer>());
        return "user/juego";
    }

    @PostMapping("/juego/submit")
    public String jugar(@RequestParam int numero,
                        @ModelAttribute("numeroAdivinar") int numeroAdivinar,
                        @ModelAttribute("intentos") int intentos,
                        @ModelAttribute("numerosIntentados") List<Integer> numerosIntentados,
                        @ModelAttribute("partidas") List<Map<String, Object>> partidas,
                        Model model) {

        if (numero < 1 || numero > 100) {
            model.addAttribute("error", "Número debe estar entre 1 y 100");
            return "user/juego";
        }

        intentos++;
        numerosIntentados.add(numero);

        if (numero == numeroAdivinar) {
            int puntaje = 100 - (intentos * 10);
            Map<String, Object> partida = Map.of(
                    "fecha", LocalDateTime.now(),
                    "resultado", "Ganó",
                    "puntaje", puntaje,
                    "intentos", intentos,
                    "respuesta", numeroAdivinar,
                    "numerosIntentados", new ArrayList<>(numerosIntentados)
            );
            partidas.add(partida);
            model.addAttribute("resultado", "¡Ganaste!");
            model.addAttribute("puntaje", puntaje);
            return "user/resultado";
        } else if (intentos >= 5) {
            Map<String, Object> partida = Map.of(
                    "fecha", LocalDateTime.now(),
                    "resultado", "Perdió",
                    "puntaje", 0,
                    "intentos", intentos,
                    "respuesta", numeroAdivinar,
                    "numerosIntentados", new ArrayList<>(numerosIntentados)
            );
            partidas.add(partida);
            model.addAttribute("resultado", "¡Perdiste! El número era " + numeroAdivinar);
            model.addAttribute("puntaje", 0);
            return "user/resultado";
        } else {
            model.addAttribute("mensaje", numero < numeroAdivinar ? "El número es mayor" : "El número es menor");
            model.addAttribute("intentos", intentos);
            return "user/juego";
        }
    }

    @GetMapping("/partidas")
    public String mostrarPartidas(@ModelAttribute("partidas") List<Map<String, Object>> partidas, Model model) {
        model.addAttribute("partidas", partidas);
        return "user/partidas";
    }

    @GetMapping("/partidas/{index}")
    public String detallePartida(@PathVariable int index,
                                 @ModelAttribute("partidas") List<Map<String, Object>> partidas,
                                 Model model) {
        if (index < 0 || index >= partidas.size()) {
            return "redirect:/user/partidas";
        }
        model.addAttribute("partida", partidas.get(index));
        return "user/detallePartida";
    }
}
