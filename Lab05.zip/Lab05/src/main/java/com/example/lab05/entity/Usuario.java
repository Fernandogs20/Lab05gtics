package com.example.lab05.entity;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "usuario")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Usuario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idUsuario;

    private String nombre;
    private String apellido;
    private String dni;
    private String email;
    private int edad;
    private String pwd;
    private boolean activo;

    @ManyToOne
    @JoinColumn(name = "idrol", nullable = false)
    private Rol rol;
}