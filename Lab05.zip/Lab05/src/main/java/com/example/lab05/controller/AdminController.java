package com.example.lab05.controller;

import com.example.lab05.entity.Rol;
import com.example.lab05.entity.Usuario;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import com.example.lab05.repository.RolRepository;
import com.example.lab05.repository.UsuarioRepository;

@Controller
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private UsuarioRepository usuarioRepo;

    @Autowired
    private RolRepository rolRepo;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @GetMapping("/usuarios")
    public String listarUsuarios(Model model) {
        model.addAttribute("usuarios", usuarioRepo.findAll());
        return "admin/usuarios";
    }

    @GetMapping("/usuarios/nuevo")
    public String nuevoUsuarioForm(Model model) {
        model.addAttribute("usuario", new Usuario());
        return "admin/formUsuario";
    }

    @PostMapping("/usuarios/guardar")
    public String guardarUsuario(@ModelAttribute Usuario usuario) {
        Rol rolUser = rolRepo.findByNombre("USER");
        usuario.setRol(rolUser);
        usuario.setActivo(true);
        usuario.setPwd(passwordEncoder.encode(usuario.getPwd()));
        usuarioRepo.save(usuario);
        return "redirect:/admin/usuarios";
    }

    @GetMapping("/")
    public String adivinanzas(Model model, Authentication auth) {
        String role = auth.getAuthorities().stream()
                .findFirst()
                .map(GrantedAuthority::getAuthority)
                .orElse("ROLE_USER")
                .replace("ROLE_", "");
        model.addAttribute("role", role);
        return "adivinanzas";
    }

}
