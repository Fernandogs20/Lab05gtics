package com.example.lab05.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller

public class LoginController {

    @GetMapping("/login")
    public String loginPage() {
        return "login"; // login.html
    }
}
